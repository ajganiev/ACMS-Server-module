#ifndef ACMS_MESSAGE_H
#define ACMS_MESSAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"
#include "../airplane/plane.h"

enum CMD {
    AUTH = 0
};

typedef struct {
    enum CMD command;
    char sender[SENDER_MAXSIZE];
    char payload[DATA_MAXSIZE];
}  g_msg;

typedef struct {
    enum CMD command;
    char sender[SENDER_MAXSIZE];
    void* payload;
} data_msg;

typedef struct {
    char name[10];
    char login[10];
    char password[10];
} account;



int prep_data_msg_plane(enum CMD cmd, char *sender, char *data, data_msg *message)
{
    plane_data payload;
    sprintf(payload.uuid, "%s", "ice-235");
    payload.speed = 434.5;
    payload.x = 23.45;
    payload.y = 45.43;
    payload.height = 1235.5;
    message->command = cmd;
    sprintf(message->sender, "%s", sender);
    message->payload = payload;
    return 0;
}

int prep_cmd(enum CMD cmd, char *sender, char *data, g_msg *message)
{
    message->command = cmd;
    sprintf(message->sender, "%s", sender);
    sprintf(message->payload, "%s", data);
    return 0;
}

int log_msg(data_msg *message)
{
    printf("[ACMS][MSG]: Type: %d: Sender %s \n", message->command, message->sender);
    printf("[ACMS][MSG]: Payload: %lf \n", message->payload.height);
    return 0;
}

#endif //ACMS_MESSAGE_H
